package com.example.cadenceoverlay
import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var statusText: TextView
    private lateinit var deviceList: ListView
    private val devices = mutableListOf<String>() // "Name\nAA:BB:..."
    private val addresses = mutableListOf<String>()
    private lateinit var adapter: ArrayAdapter<String>
    private var connectedAddress: String? = null

    private val rpmReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action == CadenceService.ACTION_UPDATE) {
                val rpm = i.getIntExtra("rpm", -1)
                val name = i.getStringExtra("device") ?: ""
                statusText.text = if (rpm >= 0) "Status: Connected to $name - RPM: $rpm" else "Status: Connected to $name - RPM: --"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        statusText = findViewById(R.id.statusText)
        deviceList = findViewById(R.id.deviceList)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, devices)
        deviceList.adapter = adapter
        deviceList.setOnItemClickListener { _, _, pos, _ ->
            connectedAddress = addresses[pos]
            val intent = Intent(this, CadenceService::class.java).apply {
                action = CadenceService.ACTION_CONNECT; putExtra("address", addresses[pos])
            }
            ContextCompat.startForegroundService(this, intent)
            statusText.text = "Status: Connecting to ${devices[pos]}..."
            Toast.makeText(this, "Connecting...", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.scanBtn).setOnClickListener { requestPermsAndScan() }
        findViewById<Button>(R.id.overlayBtn).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Allow Display over other apps, then tap START OVERLAY again", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            ContextCompat.startForegroundService(this, Intent(this, CadenceService::class.java).apply { action = CadenceService.ACTION_START_OVERLAY })
            Toast.makeText(this, "Overlay started - press HOME then open SmartTube", Toast.LENGTH_LONG).show()
        }
        findViewById<Button>(R.id.stopBtn).setOnClickListener {
            startService(Intent(this, CadenceService::class.java).apply { action = CadenceService.ACTION_STOP })
        }
        // Listen for scan results
        registerReceiver(object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i?.action == CadenceService.ACTION_DEVICE) {
                    val name = i.getStringExtra("name") ?: "Unknown"
                    val addr = i.getStringExtra("address") ?: return
                    if (!addresses.contains(addr)) { addresses.add(addr); devices.add("$name\n$addr"); adapter.notifyDataSetChanged() }
                }
            }
        }, IntentFilter(CadenceService.ACTION_DEVICE), RECEIVER_EXPORTED)
    }
    override fun onResume() { super.onResume(); registerReceiver(rpmReceiver, IntentFilter(CadenceService.ACTION_UPDATE), RECEIVER_EXPORTED) }
    override fun onPause() { super.onPause(); try { unregisterReceiver(rpmReceiver) } catch (_: Exception) {} }
    private fun requestPermsAndScan() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) { perms.add(Manifest.permission.BLUETOOTH_SCAN); perms.add(Manifest.permission.BLUETOOTH_CONNECT) }
        else perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1); return }
        startScan()
    }
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) { super.onRequestPermissionsResult(rc, p, r); startScan() }
    private fun startScan() {
        devices.clear(); addresses.clear(); adapter.notifyDataSetChanged()
        ContextCompat.startForegroundService(this, Intent(this, CadenceService::class.java).apply { action = CadenceService.ACTION_SCAN })
        Toast.makeText(this, "Scanning 10s - pedal to wake sensor", Toast.LENGTH_SHORT).show()
    }
}
