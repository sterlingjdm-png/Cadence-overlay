package com.example.cadenceoverlay
import android.app.*
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import java.util.*

class CadenceService : Service() {
    companion object {
        const val ACTION_SCAN = "SCAN"; const val ACTION_CONNECT = "CONNECT"
        const val ACTION_START_OVERLAY = "START_OVERLAY"; const val ACTION_STOP = "STOP"
        const val ACTION_DEVICE = "com.example.cadenceoverlay.DEVICE"
        const val ACTION_UPDATE = "com.example.cadenceoverlay.UPDATE"
        val CSC_SERVICE: UUID = UUID.fromString("00001816-0000-1000-8000-00805f9b34fb")
        val CSC_MEASUREMENT: UUID = UUID.fromString("00002a5b-0000-1000-8000-00805f9b34fb")
    }
    private var manager: BluetoothManager? = null
    private var gatt: BluetoothGatt? = null
    private var scanner: BluetoothLeScanner? = null
    private var overlayView: View? = null
    private var rpmText: TextView? = null
    private var statusDot: View? = null
    private var wm: WindowManager? = null
    private var lastCrankRevs = -1; private var lastCrankTime = -1; private var currentRpm = -1
    private var lastUpdate = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val timeoutCheck = object : Runnable { override fun run() { if (System.currentTimeMillis() - lastUpdate > 3000 && currentRpm != 0) { currentRpm = 0; updateOverlay() }; handler.postDelayed(this, 1000) } }

    override fun onBind(i: Intent?) = null
    override fun onCreate() {
        super.onCreate()
        manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        createChannel()
        startForeground(1, NotificationCompat.Builder(this, "cad").setContentTitle("Cadence Overlay").setContentText("Listening for cadence sensor").setSmallIcon(android.R.drawable.ic_dialog_info).build())
        handler.post(timeoutCheck)
    }
    private fun createChannel() { val ch = NotificationChannel("cad", "Cadence", NotificationManager.IMPORTANCE_LOW); (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SCAN -> startScan()
            ACTION_CONNECT -> intent.getStringExtra("address")?.let { connect(it) }
            ACTION_START_OVERLAY -> showOverlay()
            ACTION_STOP -> { hideOverlay(); stopSelf() }
        }
        return START_STICKY
    }
    private fun startScan() {
        try {
            scanner = manager?.adapter?.bluetoothLeScanner
            val cb = object : ScanCallback() {
                override fun onScanResult(type: Int, r: ScanResult?) {
                    val d = r?.device ?: return
                    val name = try { d.name } catch (_: SecurityException) { null } ?: r.scanRecord?.deviceName ?: "Unknown sensor"
                    sendBroadcast(Intent(ACTION_DEVICE).putExtra("name", name).putExtra("address", d.address).setPackage(packageName))
                }
            }
            scanner?.startScan(cb)
            handler.postDelayed({ try { scanner?.stopScan(cb) } catch (_: Exception) {} }, 10000)
        } catch (_: SecurityException) {}
    }
    private fun connect(address: String) {
        try {
            gatt?.close()
            val dev = manager?.adapter?.getRemoteDevice(address) ?: return
            gatt = dev.connectGatt(this, false, object : BluetoothGattCallback() {
                override fun onConnectionStateChange(g: BluetoothGatt?, s: Int, ns: Int) {
                    if (ns == BluetoothProfile.STATE_CONNECTED) { try { g?.discoverServices() } catch (_: SecurityException) {} }
                    else if (ns == BluetoothProfile.STATE_DISCONNECTED) { currentRpm = -1; updateOverlay() }
                }
                override fun onServicesDiscovered(g: BluetoothGatt?, st: Int) {
                    val svc = g?.getService(CSC_SERVICE) ?: return
                    val ch = svc.getCharacteristic(CSC_MEASUREMENT) ?: return
                    try { g.setCharacteristicNotification(ch, true) } catch (_: SecurityException) {}
                    val desc = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
                    if (desc != null) { desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; try { g.writeDescriptor(desc) } catch (_: SecurityException) {} }
                }
                override fun onCharacteristicChanged(g: BluetoothGatt?, ch: BluetoothGattCharacteristic?, v: ByteArray?) {
                    if (ch?.uuid == CSC_MEASUREMENT && v != null) parseCsc(v)
                }
                @Deprecated("Deprecated") override fun onCharacteristicChanged(g: BluetoothGatt?, ch: BluetoothGattCharacteristic?) { ch?.value?.let { parseCsc(it) } }
            })
        } catch (_: SecurityException) {}
    }
    // CSC Measurement: [flags][wheelRevs(4) + wheelTime(2) if present][crankRevs(2) + crankTime(2) if present]
    private fun parseCsc(v: ByteArray) {
        if (v.isEmpty()) return
        var idx = 1
        val flags = v[0].toInt()
        val wheelPresent = flags and 0x01 != 0
        val crankPresent = flags and 0x02 != 0
        if (wheelPresent) idx += 6
        if (crankPresent && v.size >= idx + 4) {
            val revs = (v[idx].toInt() and 0xFF) or ((v[idx+1].toInt() and 0xFF) shl 8)
            val time = (v[idx+2].toInt() and 0xFF) or ((v[idx+3].toInt() and 0xFF) shl 8) // 1/1024 s, wraps at 65536
            if (lastCrankRevs >= 0) {
                var dRevs = revs - lastCrankRevs; if (dRevs < 0) dRevs += 65536
                var dTime = time - lastCrankTime; if (dTime < 0) dTime += 65536
                if (dRevs > 0 && dTime > 0) { currentRpm = (dRevs * 61440 / dTime).coerceIn(0, 300); lastUpdate = System.currentTimeMillis(); updateOverlay() }
            }
            lastCrankRevs = revs; lastCrankTime = time
        }
    }
    private fun updateOverlay() {
        handler.post {
            rpmText?.text = if (currentRpm >= 0) "$currentRpm" else "--"
            statusDot?.setBackgroundColor(if (currentRpm >= 0) Color.GREEN else Color.RED)
        }
        sendBroadcast(Intent(ACTION_UPDATE).putExtra("rpm", currentRpm).putExtra("device", "sensor").setPackage(packageName))
    }
    private fun showOverlay() {
        if (overlayView != null) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val layout = FrameLayout(this).apply { setBackgroundColor(Color.argb(140, 0, 0, 0)); setPadding(24, 16, 24, 16) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.CENTER }
        rpmText = TextView(this).apply { text = "--"; textSize = 64f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); gravity = android.view.Gravity.CENTER }
        val label = TextView(this).apply { text = "RPM  CADENCE"; textSize = 14f; setTextColor(Color.LTGRAY); gravity = android.view.Gravity.CENTER }
        statusDot = View(this).apply { layoutParams = LinearLayout.LayoutParams(18, 18) }
        col.addView(rpmText); col.addView(label); col.addView(statusDot); layout.addView(col)
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply { gravity = android.view.Gravity.TOP or android.view.Gravity.END; x = 24; y = 24 }
        // Drag with mouse / touch - overlay is NOT_FOCUSABLE so SmartTube remote still works
        var lastX = 0f; var lastY = 0f
        layout.setOnTouchListener { _, e -> when (e.action) { MotionEvent.ACTION_DOWN -> { lastX = e.rawX; lastY = e.rawY; true }; MotionEvent.ACTION_MOVE -> { params.x -= (e.rawX - lastX).toInt(); params.y += (e.rawY - lastY).toInt(); lastX = e.rawX; lastY = e.rawY; try { wm?.updateViewLayout(layout, params) } catch (_: Exception) {}; true } else -> false } }
        try { wm?.addView(layout, params); overlayView = layout } catch (_: Exception) {}
        updateOverlay()
    }
    private fun hideOverlay() { try { overlayView?.let { wm?.removeView(it) } } catch (_: Exception) {}; overlayView = null }
    override fun onDestroy() { super.onDestroy(); try { gatt?.close() } catch (_: Exception) {}; hideOverlay(); handler.removeCallbacks(timeoutCheck) }
}
